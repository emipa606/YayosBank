﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using RimWorld.Planet;
using Verse;
using Verse.Sound;
using HarmonyLib;
using System.Reflection;
using System.Reflection.Emit;
using UnityEngine;

namespace rimstocks {

	[StaticConstructorOnStartup]
	public static class Harmony_SomeNamespace
	{
		public const int modularTicksUnit = 60000; //하루의 길이, 하루에 두번이상 저장할시 그날 데이터 덮어씀

		//WorldComponent_PriceSaveLoad.savePrice 로 가격 저장, 
		//WorldComponent_PriceSaveLoad.loadPrice 로 가격 불러오기

		static Harmony_SomeNamespace()
		{
			HarmonyLib.Harmony harmony = new HarmonyLib.Harmony("yayo.rimstocks.2");

			harmony.Patch(
				AccessTools.Method(typeof(MainTabWindow_History), "PreOpen"),
				null,
				new HarmonyMethod(typeof(rimstocks.Harmony_SomeNamespace), nameof(rimstocks.Harmony_SomeNamespace.patch_preOpen1))
			);
			harmony.Patch(
				AccessTools.Method(typeof(MainTabWindow_History), "PreOpen"),
				null,
				null,
				new HarmonyMethod(typeof(rimstocks.Harmony_SomeNamespace), nameof(rimstocks.Harmony_SomeNamespace.graphTranspiler))
			);

			harmony.Patch(
				AccessTools.Method(typeof(MainTabWindow_History), "DoWindowContents"),
				null,
				new HarmonyMethod(typeof(rimstocks.Harmony_SomeNamespace), nameof(rimstocks.Harmony_SomeNamespace.DoWindowContentsPostFix))
			);
		}

		public static void ExtraTabFunc(List<TabRecord> list)
		{

			list.Add(new TabRecord("Statistics".Translate(), delegate ()
			{
				CurTabAccessor.SetValue(null, (byte)2, BindingFlags.NonPublic | BindingFlags.Static, null, null);
			}, () => (byte)CurTabAccessor.GetValue(null) == 2));
			list.Add(new TabRecord("warbond_graphTitle".Translate(), delegate ()
			{
				CurTabAccessor.SetValue(null, (byte)3, BindingFlags.NonPublic | BindingFlags.Static, null, null);
			}, () => (byte)CurTabAccessor.GetValue(null) == 3));
			CurTabAccessor.SetValue(null, (byte)3, BindingFlags.NonPublic | BindingFlags.Static, null, null);
		}
		public static MethodInfo ExtraTabTranspilerCall = AccessTools.Method(typeof(Harmony_SomeNamespace), "ExtraTabFunc", null, null);
		public static FieldInfo CurTabAccessor = AccessTools.DeclaredField(typeof(MainTabWindow_History), "curTab");
		public static FieldInfo TabsAccessor = AccessTools.DeclaredField(typeof(MainTabWindow_History), "tabs");

		private static List<CurveMark> marks = new List<CurveMark>();

		public static CustomGraphGroup customGraphGroup = new CustomGraphGroup();
		public static void DoWindowContentsPostFix(Rect rect, HistoryAutoRecorderGroup ___historyAutoRecorderGroup, ref FloatRange ___graphSection)
		{
			if ((byte)CurTabAccessor.GetValue(null) == 3)
			{
				rect.yMin += 45f;
				rect.yMin += 17f;
				GUI.BeginGroup(rect);
				Rect graphRect = new Rect(0f, 0f, rect.width, 450f);
				Rect legendRect = new Rect(0f, graphRect.yMax, rect.width - 200, rect.height - graphRect.yMax);
				Rect rect2 = new Rect(0f, legendRect.yMax, rect.width, 40f);
				customGraphGroup.DrawGraph(graphRect, legendRect, ___graphSection);
				Text.Font = GameFont.Small;
				float num = (float)Core.AbsTickGame / GenDate.TicksPerDay;
				if (Widgets.ButtonText(new Rect(graphRect.xMin + graphRect.width - 200, graphRect.yMax, 100f, 40f), "Last30Days".Translate(), true, true, true))
				{
					___graphSection = new FloatRange(Mathf.Max(0f, num - 30f), num);
					SoundDefOf.Click.PlayOneShotOnCamera(null);
				}
				if (Widgets.ButtonText(new Rect(graphRect.xMin + graphRect.width - 100, graphRect.yMax, 100f, 40f), "Last100Days".Translate(), true, true, true))
				{
					___graphSection = new FloatRange(Mathf.Max(0f, num - 100f), num);
					SoundDefOf.Click.PlayOneShotOnCamera(null);
				}
				if (Widgets.ButtonText(new Rect(graphRect.xMin + graphRect.width - 200, graphRect.yMax + 40, 100f, 40f), "Last300Days".Translate(), true, true, true))
				{
					___graphSection = new FloatRange(Mathf.Max(0f, num - 300f), num);
					SoundDefOf.Click.PlayOneShotOnCamera(null);
				}
				if (Widgets.ButtonText(new Rect(graphRect.xMin + graphRect.width - 100, graphRect.yMax + 40, 100f, 40f), "AllDays".Translate(), true, true, true))
				{
					___graphSection = new FloatRange(0f, num);
					SoundDefOf.Click.PlayOneShotOnCamera(null);
				}
				GUI.EndGroup();
			}
		}

		public static void patch_preOpen1(ref FloatRange ___graphSection)
		{
			float num = (float)Core.AbsTickGame / GenDate.TicksPerDay;
			___graphSection = new FloatRange(Mathf.Max(0f, num - 30f), num);
		}

		public static IEnumerable<CodeInstruction> graphTranspiler(ILGenerator generator, IEnumerable<CodeInstruction> instructions)
		{
			int callVirt4 = 0;
			int nopStack = 0;
			int voidStack = 0;
			foreach (CodeInstruction ci in instructions)
			{
				if (voidStack > 0)
				{
					voidStack -= 1;
				}
				else if (nopStack > 0)
				{
					nopStack -= 1;
					yield return new CodeInstruction(OpCodes.Nop);
				}
				else
				{
					yield return ci;
					if (ci.opcode == OpCodes.Callvirt)
					{
						callVirt4 += 1;
					}
					if (callVirt4 == 3)
					{
						callVirt4 = -9999;
						voidStack = 3;
						nopStack = 25 - voidStack;
						yield return new CodeInstruction(OpCodes.Ldarg_0);
						yield return new CodeInstruction(OpCodes.Ldfld, TabsAccessor);
						yield return new CodeInstruction(OpCodes.Call, ExtraTabTranspilerCall);
					}
				}
			}
		}
	}

	public class CustomGraphGroup
	{
		public void DrawGraph(Rect graphRect, Rect legendRect, FloatRange section)
		{
			int ticksGame = Core.AbsTickGame;
			if (ticksGame != this.cachedGraphTickCount)
			{
				this.cachedGraphTickCount = ticksGame;
				this.curves.Clear();
				//foreach (string faction in WorldComponent_PriceSaveLoad.staticInstance.factionToPriceData.Keys)
				foreach (FactionDef f in Core.ar_faction)
				{
					string key = util.factionDefNameToKey(f.defName);
					if (!WorldComponent_PriceSaveLoad.staticInstance.factionToPriceData.Keys.Contains(key)) continue;
					FactionPriceData rs = WorldComponent_PriceSaveLoad.staticInstance.func_289013(key);
					if (rs.graphEnabled)
					{
						SimpleCurveDrawInfo simpleCurveDrawInfo = new SimpleCurveDrawInfo();
						simpleCurveDrawInfo.color = rs.color;
						simpleCurveDrawInfo.label = rs.label;
						simpleCurveDrawInfo.curve = new SimpleCurve();
						foreach (KeyValuePair<int, float> kvp in rs.timeToPriceData)
						{
							simpleCurveDrawInfo.curve.Add(new CurvePoint(kvp.Key, kvp.Value), false);
						}
						simpleCurveDrawInfo.curve.SortPoints();
						this.curves.Add(simpleCurveDrawInfo);
					}
				}
			}
			if (Mathf.Approximately(section.min, section.max))
			{
				section.max += 1.66666669E-05f;
			}
			SimpleCurveDrawerStyle curveDrawerStyle = Find.History.curveDrawerStyle;
			curveDrawerStyle.FixedSection = section;
			curveDrawerStyle.UseFixedScale = false;
			curveDrawerStyle.FixedScale = default(Vector2);
			curveDrawerStyle.YIntegersOnly = false;
			curveDrawerStyle.OnlyPositiveValues = true;
			DrawCurves(graphRect, this.curves, curveDrawerStyle, legendRect);
			Text.Anchor = TextAnchor.UpperLeft;
		}
		private List<SimpleCurveDrawInfo> curves = new List<SimpleCurveDrawInfo>();
		private int cachedGraphTickCount = -1;

		public static void DrawCurves(Rect rect, List<SimpleCurveDrawInfo> curves, SimpleCurveDrawerStyle style = null, Rect legendRect = default(Rect))
		{
			if (Event.current.type != EventType.Repaint)
			{
				return;
			}
			if (style == null)
			{
				style = new SimpleCurveDrawerStyle();
			}
			bool flag = true;
			Rect viewRect = default(Rect);
			for (int i = 0; i < curves.Count; i++)
			{
				SimpleCurveDrawInfo simpleCurveDrawInfo = curves[i];
				if (simpleCurveDrawInfo.curve != null)
				{
					if (flag)
					{
						flag = false;
						viewRect = simpleCurveDrawInfo.curve.View.rect;
					}
					else
					{
						viewRect.xMin = Mathf.Min(viewRect.xMin, simpleCurveDrawInfo.curve.View.rect.xMin);
						viewRect.xMax = Mathf.Max(viewRect.xMax, simpleCurveDrawInfo.curve.View.rect.xMax);
						viewRect.yMin = Mathf.Min(viewRect.yMin, simpleCurveDrawInfo.curve.View.rect.yMin);
						viewRect.yMax = Mathf.Max(viewRect.yMax, simpleCurveDrawInfo.curve.View.rect.yMax);
					}
				}
			}
			if (style.UseFixedScale)
			{
				viewRect.yMin = style.FixedScale.x;
				viewRect.yMax = style.FixedScale.y;
			}
			if (style.OnlyPositiveValues)
			{
				if (viewRect.xMin < 0f)
				{
					viewRect.xMin = 0f;
				}
				if (viewRect.yMin < 0f)
				{
					viewRect.yMin = 0f;
				}
			}
			if (style.UseFixedSection)
			{
				viewRect.xMin = style.FixedSection.min;
				viewRect.xMax = style.FixedSection.max;
			}
			if (style.DrawLegend)
			{
				DrawCurvesLegend(legendRect);
			}
			if (Mathf.Approximately(viewRect.width, 0f) || Mathf.Approximately(viewRect.height, 0f))
			{
				return;
			}
			Rect rect2 = rect;
			if (style.DrawMeasures)
			{
				rect2.xMin += 60f;
				rect2.yMax -= 30f;
			}
			if (style.DrawBackground)
			{
				GUI.color = new Color(0.1f, 0.1f, 0.1f);
				GUI.DrawTexture(rect2, BaseContent.WhiteTex);
			}
			if (style.DrawBackgroundLines)
			{
				SimpleCurveDrawer.DrawGraphBackgroundLines(rect2, viewRect);
			}
			if (style.DrawMeasures)
			{
				SimpleCurveDrawer.DrawCurveMeasures(rect, viewRect, rect2, style.MeasureLabelsXCount, style.MeasureLabelsYCount, style.XIntegersOnly, style.YIntegersOnly);
			}
			foreach (SimpleCurveDrawInfo curve in curves)
			{
				SimpleCurveDrawer.DrawCurveLines(rect2, curve, style.DrawPoints, viewRect, style.UseAntiAliasedLines, style.PointsRemoveOptimization);
			}
			if (style.DrawCurveMousePoint)
			{
				SimpleCurveDrawer.DrawCurveMousePoint(curves, rect2, viewRect, style.LabelX);
			}
		}

		public static void DrawCurvesLegend(Rect rect)
		{
			Text.Anchor = TextAnchor.UpperLeft;
			Text.Font = GameFont.Small;
			Text.WordWrap = false;
			GUI.BeginGroup(rect);
			float num = 0f;
			float num2 = 0f;
			int num3 = (int)(rect.width / 140f);
			int num4 = 0;
			foreach (FactionDef fd in Core.ar_faction)
			{
				string key = util.factionDefNameToKey(fd.defName);
				if (!WorldComponent_PriceSaveLoad.staticInstance.factionToPriceData.Keys.Contains(key)) continue;
				FactionPriceData rs = WorldComponent_PriceSaveLoad.staticInstance.func_289013(key);
				GUI.color = rs.color;
				GUI.DrawTexture(new Rect(num, num2 + 18.0f, 130f, 3f), BaseContent.WhiteTex);
				GUI.color = Color.white;
				Widgets.Checkbox(new Vector2(num, num2), ref rs.graphEnabled);


				FactionDef f = FactionDef.Named(rs.defname);
				if (f != null && f.FactionIcon != null)
				{
					Texture2D tex = f.FactionIcon;
					if (f.colorSpectrum != null && f.colorSpectrum.Count > 0)
					{
						GUI.color = f.colorSpectrum[0];
					}
					else
					{
						GUI.color = Color.white;
					}

					GUI.DrawTexture(new Rect(num + 20, num2 - 1f, 25f, 25f), tex); // rect 2번째값 작을수록 y축 위쪽으로 이동
				}

				GUI.color = Color.white;

				if (rs.label != null)
				{
					Widgets.Label(new Rect(num + 45, num2, 85f, 100f), rs.label);
				}
				num4++;
				if (num4 == num3)
				{
					num4 = 0;
					num = 0f;
					num2 += 20f;
				}
				else
				{
					num += 140f;
				}
			}
			GUI.EndGroup();
			GUI.color = Color.white;
			Text.WordWrap = true;
		}

	}

	public class FactionData : IExposable
	{
		public int loan;
		public int loan_totalTick;
		public int loan_targetTick;
		public float loan_per;
		public float loan_raidMulti;

		public int loan_leftTick => loan_targetTick - Find.TickManager.TicksGame;
		public int loan_flowTick => loan_totalTick - loan_leftTick;

		public void ExposeData()
		{
			Scribe_Values.Look<int>(ref loan, "loan");
			Scribe_Values.Look<int>(ref loan_totalTick, "loan_totalTick");
			Scribe_Values.Look<int>(ref loan_targetTick, "loan_targetTick");
			Scribe_Values.Look<float>(ref loan_per, "loan_per");
			Scribe_Values.Look<float>(ref loan_raidMulti, "loan_raidMulti");
		}

		public void clear()
        {
			loan = 0;
			loan_totalTick = 0;
			loan_targetTick = 0;
			loan_per = 0f;
			loan_raidMulti = 0f;
		}
	}

	public class FactionPriceData : IExposable {
		public bool graphEnabled = true;
		public string defname;
		public string label;
		public Color color;
		public Dictionary<int, float> timeToPriceData = new Dictionary<int, float>();
		public Dictionary<int, float> timeToTrendData = new Dictionary<int, float>();
		//public float loan = 0f;
		//public int loan_day = 0;
		public void ExposeData()
		{
			Scribe_Values.Look<bool>(ref graphEnabled, "graphEnabled", true);
			Scribe_Values.Look<string>(ref defname, "defname", "defname");
			Scribe_Values.Look<string>(ref label, "label", "FACTIONNAME");
			Scribe_Values.Look<Color>(ref color, "color", default(Color));
			Scribe_Collections.Look<int, float>(ref timeToPriceData, "timeToPriceData", LookMode.Value, LookMode.Value);
			Scribe_Collections.Look<int, float>(ref timeToTrendData, "timeToTrendData", LookMode.Value, LookMode.Value);
			//Scribe_Values.Look<float>(ref loan, "loan");
			//Scribe_Values.Look<int>(ref loan_day, "loan_day");
		}
		public void savePrice(float tick, float price)
		{
			int unitTime = Mathf.FloorToInt(tick / Harmony_SomeNamespace.modularTicksUnit);
			if(timeToPriceData.ContainsKey(unitTime))
			{
				timeToPriceData.Remove(unitTime);
			}
			timeToPriceData.Add(unitTime, price);
		}
		public float loadPrice(float tick)
		{
			int unitTime = Mathf.FloorToInt(tick / Harmony_SomeNamespace.modularTicksUnit);
			if(timeToPriceData.ContainsKey(unitTime))
			{
				return timeToPriceData[unitTime];
			}
            if (modBase.use_rimwar && FactionDef.Named(defname) != null)
            {
				return Core.getRimwarPriceByDef(FactionDef.Named(defname));
            }
			else if (FactionDef.Named(defname) != null)
            {
				return Core.getDefaultPrice(FactionDef.Named(defname));
            }
            else
            {
				return Rand.Range(200f, 6000f);
			}
			
		}

		public void saveTrend(float tick, float trend)
		{
			int unitTime = Mathf.FloorToInt(tick / Harmony_SomeNamespace.modularTicksUnit);
			if (timeToTrendData.ContainsKey(unitTime))
			{
				timeToTrendData.Remove(unitTime);
			}
			timeToTrendData.Add(unitTime, trend);
		}
		public float loadTrend(float tick)
		{
			int unitTime = Mathf.FloorToInt(tick / Harmony_SomeNamespace.modularTicksUnit);
			if (timeToTrendData.ContainsKey(unitTime))
			{
				return timeToTrendData[unitTime];
			}
			if (modBase.use_rimwar && FactionDef.Named(defname) != null)
			{
				return Core.getRimwarPriceByDef(FactionDef.Named(defname));
			}
			else if (FactionDef.Named(defname) != null)
			{
				return Core.getDefaultPrice(FactionDef.Named(defname));
			}
			else
			{
				return Rand.Range(200f, 6000f);
			}
		}
	}

	public class WorldComponent_PriceSaveLoad : WorldComponent
	{
		public Dictionary<string, FactionPriceData> factionToPriceData = new Dictionary<string, FactionPriceData>();
		public Dictionary<string, FactionData> ar_factionData = new Dictionary<string, FactionData>();
		public bool initialized = false;

		public static WorldComponent_PriceSaveLoad staticInstance;
		public WorldComponent_PriceSaveLoad(World world) : base(world)
		{
			staticInstance = this;
		}
		
		public static void savePrice(FactionDef faction, float tick, float price)
		{
			staticInstance.getFactionPriceDataFrom(faction).savePrice(tick, price);
		}
		public static float loadPrice(FactionDef faction, float tick)
		{
			return staticInstance.getFactionPriceDataFrom(faction).loadPrice(tick);
		}
		public static void saveTrend(FactionDef faction, float tick, float price)
		{
			staticInstance.getFactionPriceDataFrom(faction).saveTrend(tick, price);
		}
		public static float loadTrend(FactionDef faction, float tick)
		{
			return staticInstance.getFactionPriceDataFrom(faction).loadTrend(tick);
		}

		public FactionPriceData getFactionPriceDataFrom(FactionDef f)
		{
			string Key = util.factionDefNameToKey(f.defName);
			if (!factionToPriceData.ContainsKey(Key))
			{
				FactionPriceData fpdn = new FactionPriceData();
				fpdn.defname = f.defName;
				fpdn.label = f.label;
				if (f.colorSpectrum != null && f.colorSpectrum.Count > 0)
				{
					fpdn.color = f.colorSpectrum[0];
                }
                else
                {
					fpdn.color = Color.white;
				}
				factionToPriceData.Add(Key, fpdn);
			}
			/*
			if(t.IsPlayer)
			{//update for player since it could be renamed
				factionToPriceData[Key].label = t.GetCallLabel();
			}
			*/
			return factionToPriceData[Key];
		}
		public FactionPriceData func_289013(string Key)
		{
			if(!factionToPriceData.ContainsKey(Key))
			{
				return null;
			}
			return factionToPriceData[Key];
		}

        public override void FinalizeInit()
		{
			if (!initialized)
			{
				initialized = true;
				float ticksNow = Core.AbsTickGame;
				/*
				foreach(Faction f in Find.FactionManager.AllFactions)
				{
					savePrice(f, ticksNow, 0);
				}
				*/
				foreach (FactionDef f in from f in DefDatabase<FactionDef>.AllDefs
										 where
											  rimstocks.Core.isWarbondFaction(f)
										 select f)
				{
					if (modBase.use_rimwar)
					{
						savePrice(f, ticksNow, Core.getRimwarPriceByDef(f));
					}
					else if (f != null)
					{
						savePrice(f, ticksNow, Core.getDefaultPrice(f));
					}
					else
					{
						savePrice(f, ticksNow, Rand.Range(200f, 6000f));
					}
					
				}

			}
			else
			{
				foreach (FactionDef f in Core.ar_faction)
				{
					string key = util.factionDefNameToKey(f.defName);
					if (!WorldComponent_PriceSaveLoad.staticInstance.factionToPriceData.Keys.Contains(key)) continue;
					FactionPriceData rs = WorldComponent_PriceSaveLoad.staticInstance.func_289013(key);
					rs.defname = util.keyToFactionDefName(key);
					
				}
			}

		}

		public override void ExposeData()
		{
			Scribe_Values.Look<bool>(ref this.initialized, "initialized", false);
			Scribe_Collections.Look<string, FactionPriceData>(ref this.factionToPriceData, "yayo_FactionPriceData", LookMode.Value, LookMode.Deep);
			Scribe_Collections.Look<string, FactionData>(ref this.ar_factionData, "yayo_FactionData", LookMode.Value, LookMode.Deep);
			if(ar_factionData == null)
            {
				foreach(Faction f in Find.FactionManager.AllFactions)
                {
					FactionData data = new FactionData();
					ar_factionData.Add(f.GetUniqueLoadID(), data);
				}
            }
		}


		static public FactionData getFactionData (Faction f)
        {
			return staticInstance.getFactionData_p(f);
		}
		public FactionData getFactionData_p(Faction f)
        {
			string Key = f.GetUniqueLoadID();
			if (!ar_factionData.ContainsKey(Key))
			{
				FactionData data = new FactionData();
				data.loan = 0;
				data.loan_targetTick = 0;
				data.loan_totalTick = 0;
				data.loan_per = 0f;
				data.loan_raidMulti = 0f;
				ar_factionData.Add(Key, data);
			}
			return ar_factionData[Key];
		}



	}


	


}
