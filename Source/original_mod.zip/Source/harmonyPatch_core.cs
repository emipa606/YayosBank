﻿using System.Collections.Generic;
using RimWorld;

using HarmonyLib;
using Verse;
using System.Linq;

using System.Text;
using System.Reflection;

using Verse.AI;
using System;
using UnityEngine;


namespace rimstocks
{
    public class harmonyPatch_core : Mod
    {
        public harmonyPatch_core(ModContentPack content) : base(content)
        {
            HarmonyLib.Harmony harmony = new Harmony("yayo.rimstocks.1");
            /*
            harmony.Patch(
                AccessTools.Method(typeof(DefGenerator), "GenerateImpliedDefs_PreResolve"),
                null,
                new HarmonyMethod(typeof(rimstocks.harmonyPatch_core), nameof(rimstocks.harmonyPatch_core.Patch_DefGenerator_GenerateImpliedDefs_PreResolve))
            );
            */
            harmony.PatchAll();
        }
        /*
        static public void Patch_DefGenerator_GenerateImpliedDefs_PreResolve()
        {
            rimstocks.Core.patchDef();
        }
        */
    }

    
    [HarmonyPatch(typeof(DefGenerator), "GenerateImpliedDefs_PreResolve")]
    public class Patch_DefGenerator_GenerateImpliedDefs_PreResolve
    {
        public static void Prefix()
        {
            rimstocks.Core.patchDef();
        }

    }
    

}