﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld.QuestGen;
using Verse;
using Verse.AI;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;

namespace rimstocks
{
	public static class util
	{

		static List<Thing> rewards = new List<Thing>();


		



		// 특정 채권 모두제거 (상장폐지용)
		static public bool removeAllThingByDef(ThingDef def)
        {
			bool flag = false;
			foreach (Map m in from m in Find.Maps where m.ParentFaction == Find.FactionManager.OfPlayer select m)
			{

				List<Thing> ar = GetAllWarbondInMap(m, def);
				for (int i = ar.Count - 1; i >= 0; i--)
                {
					ar[i].Kill();
					flag = true;
				}
			}
			foreach (Caravan cv in from cv in Find.WorldObjects.Caravans where true select cv)
            {
				List<Thing> ar = GetAllWarbondInCaravan(cv, def);
				for (int i = ar.Count - 1; i >= 0; i--)
				{
					ar[i].Kill();
					flag = true;
				}
			}

				
			return flag;
		}


		// 배당금 지급
		static public void giveDividend(FactionDef f, ThingDef warbondDef)
        {

			foreach(Map m in from m in Find.Maps where m.ParentFaction == Find.FactionManager.OfPlayer select m){

				// 보상 가격 규모 설정
				int bondCount = AmountWarbondForDividend(m, warbondDef);
				float marketValue = (float)bondCount * warbondDef.BaseMarketValue * modBase.dividendPer;


				IntVec3 intVec = DropCellFinder.TradeDropSpot(m);


				// 보상 물품 DEF 리스트 생성
				rewards.Clear();
				List<ThingDef> ar_thingDef = new List<ThingDef>();
				if (!f.modContentPack.PackageId.Contains("ludeon"))
                {
					// 모드 팩션
					foreach (ThingDef t in from t in DefDatabase<ThingDef>.AllDefs
										   where
											basicThingCheck(t)
											&& t.modContentPack != null
											&& t.modContentPack.PackageId != null
											&& t.modContentPack.PackageId == f.modContentPack.PackageId
										   select t)
                    {
						ar_thingDef.Add(t);
                    }
				}
				if (ar_thingDef.Count == 0)
                {
                    if(f.techLevel >= TechLevel.Spacer)
                    {
						foreach (ThingDef t in from t in DefDatabase<ThingDef>.AllDefs
											   where
													basicThingCheck(t)
													&& t.techLevel == TechLevel.Spacer
													&& (t.modContentPack != null
													&& t.modContentPack.PackageId.Contains("ludeon"))
											   select t)
						{
							ar_thingDef.Add(t);
						}
					}
					else if(f.techLevel >= TechLevel.Industrial)
                    {
						foreach (ThingDef t in from t in DefDatabase<ThingDef>.AllDefs
											   where
													basicThingCheck(t)
													&& t.techLevel == TechLevel.Industrial
													&& (t.modContentPack != null
													&& t.modContentPack.PackageId.Contains("ludeon"))
											   select t)
						{
							ar_thingDef.Add(t);
						}
					}
					else if(f.techLevel >= TechLevel.Medieval)
                    {
						foreach (ThingDef t in from t in DefDatabase<ThingDef>.AllDefs
											   where
													basicThingCheck(t)
													&& t.techLevel == TechLevel.Medieval
													&& (t.modContentPack != null
													&& t.modContentPack.PackageId.Contains("ludeon"))
											   select t)
						{
							ar_thingDef.Add(t);
						}
					}
                    else
                    {
						foreach (ThingDef t in from t in DefDatabase<ThingDef>.AllDefs
											   where
													basicThingCheck(t)
													&& t.techLevel == TechLevel.Neolithic
													&& (t.modContentPack != null
													&& t.modContentPack.PackageId.Contains("ludeon"))
											   select t)
						{
							ar_thingDef.Add(t);
						}
					}
					if (ar_thingDef.Count == 0)
					{
						foreach (ThingDef t in from t in DefDatabase<ThingDef>.AllDefs
											   where
													basicThingCheck(t)
													&& (t.modContentPack != null
													&& t.modContentPack.PackageId.Contains("ludeon"))
											   select t)
						{
							ar_thingDef.Add(t);
						}
					}

                }


				if (ar_thingDef.Count == 0) continue;
				rewards = MakeThings(marketValue, ar_thingDef, f);

				if (rewards.Count == 0) continue;

				DropPodUtility.DropThingsNear(intVec, m, rewards, 110, canInstaDropDuringInit: false, leaveSlag: false, canRoofPunch: false, false);

				rewards.Clear();


				Messages.Message(new Message("bond.dividendArrived".Translate(warbondDef.label, bondCount, marketValue), MessageTypeDefOf.NeutralEvent));
			}

			// 배당금 물품 DEF 기본 체크
			bool basicThingCheck(ThingDef t)
            {
				return t.tradeability != Tradeability.None && t.race == null && !t.IsBuildingArtificial;
            }

			
		}

		static List<Thing> MakeThings(float marketValue, List<ThingDef> ar_def, FactionDef f)
        {
			List<Thing> ar_thing = new List<Thing>();
			Thing t;

			//ar_def.Shuffle();
			ar_def.SortByDescending<ThingDef, float>((Func<ThingDef, float>)(e => e.BaseMarketValue));
			//ar_tmp0.SortBy<DrugPolicyEntry, float>((Func<DrugPolicyEntry, float>)(e => (float)e.drug.techLevel + (e.drug.defName.Contains("fire") ? 0.1f : e.drug.defName.Contains("emp") ? 0.2f : 0f)));
			for (int i = 0; i < ar_def.Count && marketValue > 0; i++)
            {
				t = null;
				int needCount = Mathf.FloorToInt(marketValue / ar_def[i].BaseMarketValue);
				int count = Mathf.Min(ar_def[i].stackLimit, needCount);
				if (ar_def[i].MadeFromStuff)
                {
					while(needCount > 0)
                    {
						ThingDef stuff = null;
						if (GenStuff.TryRandomStuffFor(ar_def[i], out stuff, f.techLevel))
						{
							t = ThingMaker.MakeThing(ar_def[i], stuff);

							t.stackCount = count;
							ar_thing.Add(t);
							marketValue -= ar_def[i].BaseMarketValue * t.stackCount;

							needCount -= count;
                        }
					}
					
				}
                else
                {
					while (needCount > 0)
                    {
						t = ThingMaker.MakeThing(ar_def[i]);

						t.stackCount = count;
						ar_thing.Add(t);
						marketValue -= ar_def[i].BaseMarketValue * t.stackCount;

						needCount -= count;
					}
					
				}
				

			}
			if(marketValue >= 1f)
            {
				t = ThingMaker.MakeThing(ThingDefOf.Silver);
				t.stackCount = Mathf.FloorToInt(marketValue);
				ar_thing.Add(t);
			}

			foreach (Thing t2 in ar_thing)
			{
				if (t2 == null)
				{
					ar_thing.Remove(t2);
				}
				else if (t2.stackCount == 0)
				{
					ar_thing.Remove(t2);
				}
			}

			return ar_thing;

        }

		/*
		static List<Thing> GenerateThings(ThingSetMakerParams parms, List<Thing> outThings)
		{
			List<Thing> ar_thing = new List<Thing>();

			nextSeed = Rand.Int;

			float maxMass = parms.maxTotalMass ?? float.MaxValue;
			float totalMarketValue;
			List<ThingStuffPairWithQuality> list = GeneratePossibleDefs(parms, out totalMarketValue, nextSeed);
			for (int i = 0; i < list.Count; i++)
			{
				ar_thing.Add(list[i].MakeThing());
			}
			ThingSetMakerByTotalStatUtility.IncreaseStackCountsToTotalValue_NewTemp(ar_thing, totalMarketValue, (Thing x) => x.MarketValue, maxMass, satisfyMinRewardCount: true);

			return ar_thing;
		}

		static List<ThingStuffPairWithQuality> GeneratePossibleDefs(ThingSetMakerParams parms, out float totalMarketValue, int seed)
		{
			Rand.PushState(seed);
			List<ThingStuffPairWithQuality> result = GeneratePossibleDefs(parms, out totalMarketValue);
			Rand.PopState();
			return result;
		}

		static List<ThingStuffPairWithQuality> GeneratePossibleDefs(ThingSetMakerParams parms, out float totalMarketValue)
		{
			IEnumerable<ThingDef> enumerable = AllowedThingDefs(parms);
			if (!enumerable.Any())
			{
				totalMarketValue = 0f;
				return new List<ThingStuffPairWithQuality>();
			}
			TechLevel techLevel = parms.techLevel ?? TechLevel.Undefined;
			IntRange countRange = parms.countRange ?? new IntRange(1, int.MaxValue);
			FloatRange floatRange = parms.totalMarketValueRange ?? FloatRange.Zero;
			float maxMass = parms.maxTotalMass ?? float.MaxValue;
			QualityGenerator qualityGenerator = parms.qualityGenerator ?? QualityGenerator.BaseGen;
			totalMarketValue = floatRange.RandomInRange;
			return ThingSetMakerByTotalStatUtility.GenerateDefsWithPossibleTotalValue_NewTmp3(countRange, totalMarketValue, enumerable, techLevel, qualityGenerator, GetMinValue, GetMaxValue, GetSingleThingValue, null, 100, maxMass, parms.allowNonStackableDuplicates.GetValueOrDefault(true), totalMarketValue * (parms.minSingleItemMarketValuePct ?? 0f));
		}

		static IEnumerable<ThingDef> AllowedThingDefs(ThingSetMakerParams parms)
		{
			return ThingSetMakerUtility.GetAllowedThingDefs(parms);
		}

		static float GetSingleThingValue(ThingStuffPairWithQuality thingStuffPair)
		{
			return thingStuffPair.GetStatValue(StatDefOf.MarketValue);
		}
		static float GetMinValue(ThingStuffPairWithQuality thingStuffPair)
		{
			return thingStuffPair.GetStatValue(StatDefOf.MarketValue) * (float)thingStuffPair.thing.minRewardCount;
		}

		static float GetMaxValue(ThingStuffPairWithQuality thingStuffPair)
		{
			return thingStuffPair.GetStatValue(StatDefOf.MarketValue) * (float)thingStuffPair.thing.stackLimit;
		}
		*/



		private static List<Thing> GetAllWarbondInCaravan(Caravan cv, ThingDef td)
        {
			List<Thing> ar_thing = new List<Thing>();
			foreach (Thing t in from t in cv.AllThings
								where
									 t.def == td
								select t)
			{
				ar_thing.Add(t);
			}
			foreach (Pawn p in cv.pawns)
			{
				if (p.inventory == null || p.inventory.innerContainer == null) continue;

				foreach (Thing t2 in from t2 in p.inventory.innerContainer
									 where
											 t2.def == td
									 select t2)
				{
					ar_thing.Add(t2);
				}
			}

			return ar_thing;
		}

		private static List<Thing> GetAllWarbondInMap(Map map, ThingDef td)
		{
			List<Thing> ar_thing = new List<Thing>();
			foreach (Thing t in from t in map.listerThings.AllThings
								where
									 t.def == td
									 select t)
			{
				ar_thing.Add(t);
			}
			foreach (Thing t in from t in map.listerThings.AllThings
								where
									 t.TryGetComp<CompTransporter>() != null
								select t)
            {
				CompTransporter cp = t.TryGetComp<CompTransporter>();

				foreach (Thing t2 in from t2 in cp.innerContainer
									 where
											 t2.def == td
									 select t2)
				{
					ar_thing.Add(t2);
				}

			}

			foreach (Pawn p in map.mapPawns.FreeColonistsAndPrisoners)
			{
				if (p.inventory == null || p.inventory.innerContainer == null) continue;
				
				foreach (Thing t2 in from t2 in p.inventory.innerContainer
									 where
											 t2.def == td
									 select t2)
				{
					ar_thing.Add(t2);
				}

			}

			return ar_thing;
		}





		private static int AmountWarbondForDividend(Map map, ThingDef td)
		{
			return (from t in CaravanFormingUtility.AllReachableColonyItems(map)
					where t.def == td
					select t).Sum((Thing t) => t.stackCount);
		}


		private static int AmountSendableSilver(Map map)
		{
			return (from t in TradeUtility.AllLaunchableThingsForTrade(map)
					where t.def == ThingDefOf.Silver
					select t).Sum((Thing t) => t.stackCount);
		}


		private static int AmountSendableWarbond(Map map, ThingDef td)
		{
			return (from t in TradeUtility.AllLaunchableThingsForTrade(map)
					where t.def == td
					select t).Sum((Thing t) => t.stackCount);
		}

		// 통신기 메뉴 - 대출
		public static DiaOption RequestLoan(Map map, Faction faction, Pawn negotiator)
		{
			int amount = modBase.loanScale;
			float loan_per = modBase.loanPer;
			int loan_totalTick = modBase.loanDate * GenDate.TicksPerDay;
			int loan_targetTick = loan_totalTick + Find.TickManager.TicksGame;
			FactionData data = WorldComponent_PriceSaveLoad.getFactionData(faction);
			string str_leftDate = data.loan > 0 ? GenDate.ToStringTicksToPeriod(data.loan_leftTick < 0 ? 0 : data.loan_leftTick) : "-";
			string str_totalDate = GenDate.ToStringTicksToPeriod(data.loan_totalTick);

			int maxLoan = (faction.GoodwillWith(Find.FactionManager.OfPlayer) / 30 + 1) * Mathf.RoundToInt(amount * (1f + loan_per));
			string text = "loan.menu".Translate(data.loan, maxLoan, str_leftDate);



			DiaOption diaOption5 = new DiaOption(text);
			if ((int)faction.def.techLevel < 4)
			{
				diaOption5.link = FactionDialogMaker.CantMakeItInTime(faction, negotiator);
			}
			else
			{
				DiaNode diaNode;
				if(data.loan > 0)
                {
					diaNode = new DiaNode("loan.contract".Translate((loan_per * 100f).ToString("0.###"), str_leftDate, data.loan));
				}
                else
                {
					diaNode = new DiaNode("loan.contract".Translate((loan_per * 100f).ToString("0.###"), str_totalDate, data.loan));
				}


				DiaOption diaOption6 = new DiaOption("loan.get".Translate(amount));
				if (data.loan + amount > maxLoan)
				{
					diaOption6.Disable("loan.isMax".Translate());
				}
				if (data.loan > 0 && data.loan_leftTick < data.loan_totalTick - GenDate.TicksPerDay)
				{
					diaOption6.Disable("loan.needRepay".Translate());
				}
				if (faction.PlayerRelationKind == FactionRelationKind.Hostile)
				{
					diaOption6.Disable("warbond.mustBeNotHostile".Translate());
				}
				diaOption6.action = delegate
				{
					// 지급
					data.loan += Mathf.RoundToInt(amount * (1f + loan_per));
					data.loan_totalTick = loan_totalTick;
					data.loan_targetTick = loan_targetTick;
					data.loan_per = loan_per;
					IntVec3 intVec = DropCellFinder.TradeDropSpot(map);
					Thing thing = ThingMaker.MakeThing(ThingDefOf.Silver);
					thing.stackCount = amount;
					DropPodUtility.DropThingsNear(intVec, map, new List<Thing>() { thing }, 110, canInstaDropDuringInit: false, leaveSlag: false, canRoofPunch: false, false);
				};
				diaOption6.linkLateBind = FactionDialogMaker.ResetToRoot(faction, negotiator);
				diaNode.options.Add(diaOption6);

				// 빚 갚기
				if(data.loan > 0)
                {
					DiaOption diaOption8 = new DiaOption("loan.replay".Translate(data.loan));
					if (AmountSendableSilver(map) < data.loan)
					{
						diaOption8.Disable("NeedSilverLaunchable".Translate(data.loan));
					}
					diaOption8.action = delegate
					{
						TradeUtility.LaunchThingsOfType(ThingDefOf.Silver, data.loan, map, null);
						data.loan = 0;
					};
					diaOption8.linkLateBind = FactionDialogMaker.ResetToRoot(faction, negotiator);
					diaNode.options.Add(diaOption8);
				}


				DiaOption diaOption7 = new DiaOption("CancelButton".Translate());
				diaOption7.linkLateBind = FactionDialogMaker.ResetToRoot(faction, negotiator);
				diaNode.options.Add(diaOption7);

				diaOption5.link = diaNode;

			}
			return diaOption5;

		}

		public static DiaOption RequestLoanGiveUp(Map map, Faction faction, Pawn negotiator)
		{
			string text = "loan.giveUp".Translate();

			DiaOption diaOption5 = new DiaOption(text);

			int totalLoan = 0;
			foreach (Faction f in Find.FactionManager.AllFactions)
            {
				if (f.defeated) continue;
				FactionData data = WorldComponent_PriceSaveLoad.getFactionData(f);
				if (data.loan <= 0) continue;
				if(data.loan_flowTick <= GenDate.TicksPerDay)
                {
					DiaOption diaOption = new DiaOption(text);
					diaOption.Disable("loan.delay".Translate(GenDate.ToStringTicksToPeriod(GenDate.TicksPerDay - data.loan_flowTick)));
					return diaOption;
				}
				totalLoan += data.loan;
			}

			if (totalLoan <= 0)
			{
				DiaOption diaOption = new DiaOption(text);
				diaOption.Disable("loan.noLoan".Translate());
				return diaOption;
			}



			DiaNode diaNode = new DiaNode("loan.giveUp.notice1".Translate());

			DiaOption diaOption8 = new DiaOption("loan.giveUp.ok".Translate());
			diaOption8.action = delegate
			{
				clearAllLoan();
			};
			diaOption8.linkLateBind = FactionDialogMaker.ResetToRoot(faction, negotiator);
			diaNode.options.Add(diaOption8);


			DiaOption diaOption7 = new DiaOption("CancelButton".Translate());
			diaOption7.linkLateBind = FactionDialogMaker.ResetToRoot(faction, negotiator);
			diaNode.options.Add(diaOption7);

			diaOption5.link = diaNode;
			return diaOption5;


		}


		// 통신기 메뉴 - 군사요청
		public static DiaOption RequestMilitaryAidOptionWarbond(Map map, Faction faction, Pawn negotiator)
		{
			ThingDef warbondDef = ThingDef.Named($"yy_warbond_{faction.def.defName}");

			string text = "warbond.requestMilitaryAid".Translate(rimstocks.modBase.militaryAid_cost, warbondDef.label);

			if (AmountSendableWarbond(map, warbondDef) < rimstocks.modBase.militaryAid_cost)
			{
				DiaOption diaOption = new DiaOption(text);
				diaOption.Disable("warbond.noCost".Translate());
				return diaOption;
			}
			/*
			if (faction.PlayerRelationKind == FactionRelationKind.Hostile)
			{
				DiaOption diaOption = new DiaOption(text);
				diaOption.Disable("warbond.mustBeNotHostile".Translate());
				return diaOption;
			}
			*/
			if (!faction.def.allowedArrivalTemperatureRange.ExpandedBy(-4f).Includes(map.mapTemperature.SeasonalTemp))
			{
				DiaOption diaOption2 = new DiaOption(text);
				diaOption2.Disable("BadTemperature".Translate());
				return diaOption2;
			}

			int num = faction.lastMilitaryAidRequestTick + 60000 - Find.TickManager.TicksGame;
			if (num > 0)
			{
				DiaOption diaOption3 = new DiaOption(text);
				diaOption3.Disable("WaitTime".Translate(num.ToStringTicksToPeriod()));
				return diaOption3;
			}

			if (faction.PlayerRelationKind != FactionRelationKind.Hostile && NeutralGroupIncidentUtility.AnyBlockingHostileLord(map, faction))
			{
				DiaOption diaOption4 = new DiaOption(text);
				diaOption4.Disable("HostileVisitorsPresent".Translate());
				return diaOption4;
			}
			DiaOption diaOption5 = new DiaOption(text);
			if ((int)faction.def.techLevel < 4)
			{
				diaOption5.link = FactionDialogMaker.CantMakeItInTime(faction, negotiator);
			}
			else
			{
				IEnumerable<Faction> source = (from x in map.attackTargetsCache.TargetsHostileToColony
											   where GenHostility.IsActiveThreatToPlayer(x)
											   select ((Thing)x).Faction into x
											   where x != null && !x.HostileTo(faction)
											   select x).Distinct();
				if (source.Any())
				{
					DiaNode diaNode = new DiaNode("MilitaryAidConfirmMutualEnemy".Translate(faction.Name, source.Select((Faction fa) => fa.Name).ToCommaList(useAnd: true)));
					DiaOption diaOption6 = new DiaOption("CallConfirm".Translate());
					diaOption6.action = delegate
					{
						CallForAidWarBond(map, faction, warbondDef);
					};
					diaOption6.link = FactionDialogMaker.FightersSent(faction, negotiator);
					DiaOption diaOption7 = new DiaOption("CallCancel".Translate());
					diaOption7.linkLateBind = FactionDialogMaker.ResetToRoot(faction, negotiator);
					diaNode.options.Add(diaOption6);
					diaNode.options.Add(diaOption7);
					diaOption5.link = diaNode;
				}
				else
				{
					diaOption5.action = delegate
					{
						CallForAidWarBond(map, faction, warbondDef);
					};
					diaOption5.link = FactionDialogMaker.FightersSent(faction, negotiator);
				}
			}
			return diaOption5;


		}

		private static void CallForAidWarBond(Map map, Faction faction, ThingDef warbondDef)
		{
			TradeUtility.LaunchThingsOfType(warbondDef, rimstocks.modBase.militaryAid_cost, map, null);
			IncidentParms incidentParms = new IncidentParms();
			incidentParms.target = map;
			incidentParms.faction = faction;
			incidentParms.raidArrivalModeForQuickMilitaryAid = true;
			incidentParms.points = warbondDef.BaseMarketValue * rimstocks.modBase.militaryAid_multiply * 2f;

			if(faction.PlayerRelationKind == FactionRelationKind.Hostile)
            {
				incidentParms.raidArrivalMode = PawnsArrivalModeDefOf.EdgeWalkIn;
			}

			faction.lastMilitaryAidRequestTick = Find.TickManager.TicksGame;
			IncidentDefOf.RaidFriendly.Worker.TryExecute(incidentParms);
		}

		public static void RaidForLoan(Map map, Faction faction, float multiply)
		{
			IncidentParms incidentParms = new IncidentParms();
			incidentParms.target = map;
			incidentParms.faction = faction;
			incidentParms.raidArrivalModeForQuickMilitaryAid = true;
			incidentParms.points = StorytellerUtility.DefaultThreatPointsNow(incidentParms.target) * multiply;
			if (incidentParms.points > 10000) incidentParms.points = 10000;
			incidentParms.raidArrivalMode = PawnsArrivalModeDefOf.CenterDrop;
			IncidentDefOf.RaidEnemy.Worker.TryExecute(incidentParms);
		}


		// 가압류 파산
		public static void clearAllLoan()
		{
			foreach (Faction f in Find.FactionManager.AllFactions)
			{
				if (f.defeated) continue;
				FactionData data = WorldComponent_PriceSaveLoad.getFactionData(f);
				if (data.loan <= 0) continue;
				data.clear();

				List<Thing> ar_thing = new List<Thing>();

				foreach (Map m in from m in Find.Maps where m.ParentFaction == Find.FactionManager.OfPlayer select m)
				{

					foreach (Thing t in from t in m.listerThings.AllThings
										where
											checkForKill(t)
										select t)
					{
						ar_thing.Add(t);
					}

					foreach (Thing t in from t in m.listerThings.AllThings
										where
											 t.TryGetComp<CompTransporter>() != null
										select t)
					{
						CompTransporter cp = t.TryGetComp<CompTransporter>();

						foreach (Thing t2 in from t2 in cp.innerContainer
											 where
													 checkForKill(t2)
											 select t2)
						{
							ar_thing.Add(t2);
						}

					}

					foreach (Pawn p in m.mapPawns.FreeColonistsAndPrisoners)
					{
						if (p.inventory == null || p.inventory.innerContainer == null) continue;

						foreach (Thing t2 in from t2 in p.inventory.innerContainer
											 where
													 checkForKill(t2)
											 select t2)
						{
							ar_thing.Add(t2);
						}
						foreach (Thing t2 in from t2 in p.equipment.AllEquipmentListForReading
											 where
													 checkForKill(t2)
											 select t2)
						{
							ar_thing.Add(t2);
						}
						foreach (Thing t2 in from t2 in p.apparel.WornApparel
											 where
													 checkForKill(t2)
											 select t2)
						{
							ar_thing.Add(t2);
						}

					}



					
				}

				foreach (Caravan cv in from cv in Find.WorldObjects.Caravans where true select cv)
				{
					foreach (Thing t in from t in cv.AllThings
										where
											 checkForKill(t)
										select t)
					{
						ar_thing.Add(t);
					}
					foreach (Pawn p in cv.pawns)
					{
						if (p.inventory == null || p.inventory.innerContainer == null) continue;

						foreach (Thing t2 in from t2 in p.inventory.innerContainer
											 where
													 checkForKill(t2)
											 select t2)
						{
							ar_thing.Add(t2);
						}
						foreach (Thing t2 in from t2 in p.equipment.AllEquipmentListForReading
											 where
													 checkForKill(t2)
											 select t2)
						{
							ar_thing.Add(t2);
						}
						foreach (Thing t2 in from t2 in p.apparel.WornApparel
											 where
													 checkForKill(t2)
											 select t2)
						{
							ar_thing.Add(t2);
						}
					}
				}

				foreach (Thing t in ar_thing)
				{
					if(!t.Destroyed) t.Kill();
				}



				bool checkForKill(Thing t)
                {
					return (t.def.category == ThingCategory.Item 
						&& (t.def.thingCategories == null || (!t.def.thingCategories.Contains(ThingCategoryDefOf.Chunks) && !t.def.thingCategories.Contains(ThingCategoryDefOf.StoneChunks)))
						&& Rand.Chance(0.7f))
						|| t.def == ThingDefOf.Silver;
				}

			}
		}






		static public string factionDefNameToKey(string defname)
		{
			return $"warbondPrice_{defname}";
		}
		static public string keyToFactionDefName(string key)
		{
			return key.Substring(key.IndexOf('_') + 1, key.Length - key.IndexOf('_') - 1);
		}




	}
}
