﻿using RimWorld;
using System.Collections.Generic;
using HarmonyLib;
using Verse;
using UnityEngine;

using System.Linq;


namespace rimstocks
{
    // 퀘스트 완료 시 주가변동
    [HarmonyPatch(typeof(Quest), "End")]
    internal class Patch_Quest_End
    {
        static void Postfix(Quest __instance, QuestEndOutcome outcome, bool sendLetter = true)
        {
            //List<QuestPart> ar_part = Traverse.Create(__instance).Field("parts").GetValue<List<QuestPart>>();
            /*
            Log.Message("---------------------");
            foreach(Faction ffff in __instance.InvolvedFactions)
            {
                Log.Message(ffff.def.defName);
            }
            */
            FactionDef f = null;
            FactionDef f2 = null;
            if(__instance.InvolvedFactions != null && __instance.InvolvedFactions.Count() >= 2)
            {
                f = __instance.InvolvedFactions.ToList()[0].def;
                f2 = __instance.InvolvedFactions.ToList()[1].def;
            }
            else if(__instance.InvolvedFactions != null && __instance.InvolvedFactions.Count() == 1)
            {
                foreach (QuestPart p in __instance.PartsListForReading)
                {
                    if (p is QuestPart_SpawnWorldObject)
                    {
                        QuestPart_SpawnWorldObject p2 = p as QuestPart_SpawnWorldObject;
                        if (p2.worldObject.def == WorldObjectDefOf.Site && p2.worldObject.Faction != null)
                        {
                            f2 = p2.worldObject.Faction.def;
                            //Log.Message($"Site : {f2.defName}");
                        }
                    }
                    else if (p is QuestPart_Incident)
                    {
                        QuestPart_Incident p2 = p as QuestPart_Incident;
                        if (p2.incident == IncidentDefOf.RaidEnemy)
                        {
                            f2 = __instance.InvolvedFactions.ToList()[0].def;
                            //Log.Message($"RaidEnemy : {f2.defName}");
                        }
                    }
                    else if(!(p is QuestPart_InvolvedFactions))
                    {
                        if(p.InvolvedFactions.Count() > 0)
                        {
                            f = p.InvolvedFactions.ToList()[0].def;
                            //Log.Message($"others : {f.defName}");
                        }
                        
                    }
                }
                
            }
            /*
            else if(__instance.PartsListForReading != null)
            {
                foreach (QuestPart p in __instance.PartsListForReading)
                {
                    if (p != null && p.GetType() == typeof(QuestPart_FactionGoodwillChange))
                    {
                        QuestPart_FactionGoodwillChange p2 = p as QuestPart_FactionGoodwillChange;
                        f = p2.faction.def;
                    }
                }
            }
            */
            switch (outcome)
            {
                case QuestEndOutcome.Fail:
                    Core.OnQuestResult(f, f2, false, __instance.points);
                    break;
                case QuestEndOutcome.Success:
                    Core.OnQuestResult(f, f2, true, __instance.points);
                    break;
                case QuestEndOutcome.InvalidPreAcceptance:
                    Core.OnQuestResult(f, f2, true, __instance.points);
                    break;
                case QuestEndOutcome.Unknown:
                    Core.OnQuestResult(f, f2, true, __instance.points);
                    break;

            }

        }
    }



    // 팩션 연락 시, 선택지 추가
    [HarmonyPatch(typeof(FactionDialogMaker), "FactionDialogFor")]
    internal class Patch_FactionDialogMaker_FactionDialogFor
    {
        static void Postfix(ref DiaNode __result, Pawn negotiator, Faction faction)
        {
            DiaOption opt;
            bool needsSocial;
            // 대출
            if ((int)faction.def.techLevel >= 4)
            {
                opt = util.RequestLoan(negotiator.Map, faction, negotiator);
                needsSocial = true;
                if (needsSocial && negotiator.skills.GetSkill(SkillDefOf.Social).TotallyDisabled)
                {
                    opt.Disable("WorkTypeDisablesOption".Translate(SkillDefOf.Social.label));
                }
                __result.options.Insert(__result.options.Count - 1, opt);

                opt = util.RequestLoanGiveUp(negotiator.Map, faction, negotiator);
                needsSocial = true;
                if (needsSocial && negotiator.skills.GetSkill(SkillDefOf.Social).TotallyDisabled)
                {
                    opt.Disable("WorkTypeDisablesOption".Translate(SkillDefOf.Social.label));
                }
                __result.options.Insert(__result.options.Count - 1, opt);
            }
                


            // 채권 군사요청
            if (!Core.isWarbondFaction(faction.def))
            {
                return;
            }
            opt = util.RequestMilitaryAidOptionWarbond(negotiator.Map, faction, negotiator);
            needsSocial = true;
            if (needsSocial && negotiator.skills.GetSkill(SkillDefOf.Social).TotallyDisabled)
            {
                opt.Disable("WorkTypeDisablesOption".Translate(SkillDefOf.Social.label));
            }
            __result.options.Insert(__result.options.Count - 1, opt);
            
        }
    }



    // 채권 만료기한 스택 시 합치기
    [HarmonyPatch(typeof(Thing), nameof(Thing.TryAbsorbStack))]
    internal class Patch_Thing_TryAbsorbStack
    {
        [HarmonyPostfix]
        public static bool Prefix(Thing __instance, ref bool __result, Thing other, bool respectStackLimit)
        {
            CompLifespan cp = __instance.TryGetComp<CompLifespan>();
            if(cp != null)
            {
                CompLifespan cp_other = other.TryGetComp<CompLifespan>();
                if(cp_other != null)
                {
                    int num = ThingUtility.TryAbsorbStackNumToTake(__instance, other, respectStackLimit);
                    cp.age = Mathf.CeilToInt((float)(cp.age * __instance.stackCount + cp_other.age * num) / (float)(__instance.stackCount + num));
                }
                
            }
            return true;

        }
    }


    


    // 채권 고정 구입/판매 가격
    [HarmonyPatch(typeof(Tradeable), "InitPriceDataIfNeeded")]
    internal class Patch_Tradeable_InitPriceDataIfNeeded
    {
        [HarmonyPostfix]
        static void Postfix(Tradeable __instance)
        {
            if (__instance.ThingDef.tradeTags != null && __instance.ThingDef.tradeTags.Contains("warbond"))
            {
                Traverse.Create(__instance).Field("pricePlayerBuy").SetValue(__instance.ThingDef.BaseMarketValue);
                Traverse.Create(__instance).Field("pricePlayerSell").SetValue(__instance.ThingDef.BaseMarketValue * modBase.sellPrice * ((float)__instance.AnyThing.HitPoints / (float)__instance.AnyThing.MaxHitPoints));
            }
                

        }
    }


}